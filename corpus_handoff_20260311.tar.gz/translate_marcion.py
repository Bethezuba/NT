#!/usr/bin/env python3
# translate_marcion.py
# Translates Marcion's Evangelion verse by verse using Mistral via Ollama.
# Resumable. Output: sources/marcion_english.txt (tab-separated: ref\ttranslation)
#
# Run from ~/NT:
#   python3 translate_marcion.py [model]

import csv, re, os, subprocess, time, sys

NORMALIZED   = "sources/marcion_normalized.txt"
ENGLISH_OUT  = "sources/marcion_english.txt"
MODEL        = sys.argv[1] if len(sys.argv) > 1 else "mistral:7b"

MAX_RETRIES   = 2
SLEEP_BETWEEN = 0.5

def clean_greek(text):
    text = re.sub(r'\(\s*\)', '…', text)
    text = re.sub(r'…\s*…', '…', text)
    return text.strip()

# ── Same prompt as NT and Josephus — no title, no author ──
def build_prompt(ref, greek, prev, attempt=0):
    strictness = (
        "" if attempt == 0
        else " You must output English only — no Greek letters, no Latin, no commentary, no alternatives, no preamble."
    )
    return (
        f"You are translating Koine Greek into formal English. "
        f"Verse: {ref}. "
        f"Previous verse for context: {prev}. "
        f"Translate the Greek below into English. "
        f"Output only the English translation — no notes, no alternatives, no Latin, "
        f"no Greek characters, no preamble, no commentary. "
        f"Begin your response immediately with the first word of the English translation.{strictness} "
        f"Greek: {greek}"
    )

FAILURE_PATTERNS = [
    r"^the (translation|verse|greek text|passage)",
    r"^here is (the translation|a translation)",
    r"^(translation|formal english translation):",
    r"[\u0370-\u03FF\u1F00-\u1FFF]{4,}",
]

def is_bad(text):
    for pat in FAILURE_PATTERNS:
        if re.search(pat, text, re.IGNORECASE):
            return True
    if text.count("(") > 2:
        return True
    return False

def clean_output(text):
    text = re.sub(
        r"^(the (formal )?english translation( of (the )?(given )?greek (text|passage))? is:?\s*"
        r"|here is (the translation.*?|a translation.*?):\s*"
        r"|translation:\s*)",
        "", text, flags=re.IGNORECASE
    )
    text = re.sub(r'[\u0370-\u03FF\u1F00-\u1FFF]+', '', text)
    text = re.sub(r'\s+', ' ', text).strip()
    if text.startswith('"') and text.endswith('"'):
        text = text[1:-1].strip()
    return text

def translate_verse(ref, greek, prev, attempt=0):
    prompt = build_prompt(ref, greek, prev, attempt)
    try:
        result = subprocess.run(
            ["ollama", "run", MODEL, prompt],
            capture_output=True, text=True, timeout=300
        )
        raw = result.stdout.strip()
    except subprocess.TimeoutExpired:
        return None, "TIMEOUT"

    lines = []
    for line in raw.splitlines():
        l = line.strip()
        if not l:
            continue
        low = l.lower()
        if any(low.startswith(x) for x in [
            "note", "note:", "commentary", "translation:",
            "the greek", "the translation", "here is", "this passage",
        ]):
            continue
        lines.append(l)
    return clean_output(" ".join(lines)), None

def load_completed(path):
    completed = {}
    if not os.path.exists(path):
        return completed
    with open(path, encoding="utf-8") as f:
        for line in f:
            m = re.match(r"^(.+?)\t(.*)", line.rstrip('\n'))
            if m:
                completed[m.group(1)] = m.group(2)
    return completed

def main():
    # ── Load verses from normalized CSV ──
    verses = []
    seen = set()
    with open(NORMALIZED, encoding="utf-8", newline='') as f:
        reader = csv.reader(f)
        next(reader)
        for row in reader:
            if len(row) < 4:
                continue
            ch, vs, _, script = row[0], row[1], row[2], row[3]
            ref   = f"{ch.lstrip('0')}:{vs.lstrip('0')}"
            greek = clean_greek(script)
            if not greek or ref in seen:
                continue
            seen.add(ref)
            verses.append((ref, greek))

    total = len(verses)
    print(f"{total} verses to translate")
    print(f"Model: {MODEL}\n")

    completed = load_completed(ENGLISH_OUT)
    already   = len(completed)
    remaining = total - already

    if remaining == 0:
        print("Already complete!")
        return

    if already > 0:
        last_ref = list(completed.keys())[-1]
        prev = completed[last_ref]
        print(f"Resuming — {already}/{total} done, {remaining} remaining\n")
    else:
        prev = ""

    with open(ENGLISH_OUT, "a", encoding="utf-8") as outf:
        translated = 0
        failed     = []

        try:
            for ref, greek in verses:
                if ref in completed:
                    continue

                translation = None
                for attempt in range(MAX_RETRIES + 1):
                    t, err = translate_verse(ref, greek, prev, attempt)
                    if err:
                        print(f"  [{ref}] — {err}, skipping")
                        break
                    if not t:
                        continue
                    if is_bad(t):
                        if attempt < MAX_RETRIES:
                            time.sleep(1)
                            continue
                        else:
                            failed.append(ref)
                            translation = f"[REVIEW] {t}"
                            break
                    else:
                        translation = t
                        break

                if translation:
                    outf.write(f"{ref}\t{translation}\n")
                    outf.flush()
                    prev = translation.replace("[REVIEW] ", "")
                    translated += 1
                    if translated % 10 == 0:
                        print(f"  [{ref}] {translation[:80]}")

                time.sleep(SLEEP_BETWEEN)

        except KeyboardInterrupt:
            print(f"\nInterrupted — progress saved to {ENGLISH_OUT}")
            return

    print(f"\nDone — {translated} translated, {len(failed)} flagged")
    if failed:
        print(f"Flagged: {failed}")
    print(f"\nTranslations: {ENGLISH_OUT}")
    print(f"Now run: python3 build_marcion_json.py")

if __name__ == "__main__":
    main()
