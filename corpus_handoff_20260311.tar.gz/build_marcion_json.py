#!/usr/bin/env python3
# build_marcion_json.py
# Converts BeDuhn-Bilby normalized CSV → docs/data/marcion.json
# and updates docs/data/index.json
#
# Run from ~/NT:
#   python3 build_marcion_json.py
#
# Expects:
#   sources/marcion_normalized.txt   (copy of 2023-10-19_BeDuhn-Evangelion-normalized.txt)
#   sources/marcion_english.txt      (tab-separated: ref\ttranslation, optional)

import csv, json, os, re, unicodedata

NORMALIZED   = "sources/marcion_normalized.txt"
ENGLISH_FILE = "sources/marcion_english.txt"
OUT_JSON     = "docs/data/marcion.json"
INDEX_JSON   = "docs/data/index.json"

# ── Clean the Greek text ──
def clean_greek(text):
    # () = lacuna → ellipsis
    text = re.sub(r'\(\s*\)', '…', text)
    # Multiple … in a row → single
    text = re.sub(r'…\s*…', '…', text)
    # Strip leading/trailing whitespace
    text = text.strip()
    return text

# ── Load normalized CSV ──
verses = []
seen_refs = set()

with open(NORMALIZED, encoding="utf-8", newline='') as f:
    reader = csv.reader(f)
    header = next(reader)  # skip "Chapter","Verse","Version","Script"
    for row in reader:
        if len(row) < 4:
            continue
        ch, vs, version, script = row[0], row[1], row[2], row[3]
        ref = f"{ch.lstrip('0')}:{vs.lstrip('0')}"

        # Skip duplicate refs (some verses appear in multiple versions — keep first)
        if ref in seen_refs:
            continue
        seen_refs.add(ref)

        greek = clean_greek(script)
        if not greek:
            continue

        verses.append({
            "ref":     ref,
            "ch":      int(ch),
            "vs":      int(re.sub(r"[^0-9]", "", vs) or 0),
            "greek":   greek,
            "mistral": "",
            "kjv":     ""
        })

print(f"Verses loaded: {len(verses)}")

# ── Load English translations if present ──
english = {}
if os.path.exists(ENGLISH_FILE):
    with open(ENGLISH_FILE, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            parts = line.split('\t', 1)
            if len(parts) == 2:
                english[parts[0]] = parts[1]
    print(f"Translations loaded: {len(english)}")
    for v in verses:
        if v["ref"] in english:
            v["mistral"] = english[v["ref"]]
else:
    print(f"No translation file found at {ENGLISH_FILE} — Greek only for now")

# ── Remove internal sort keys before writing ──
for v in verses:
    v.pop("ch", None)
    v.pop("vs", None)

has_translation = any(v["mistral"] for v in verses)

# ── Book JSON ──
book = {
    "code":           "marcion",
    "name":           "Evangelion",
    "author":         "Marcion of Sinope (reconstructed)",
    "type":           "prose",
    "group":          "apocrypha",
    "verseCount":     len(verses),
    "hasTranslation": has_translation,
    "hasKjv":         False,
    "hasWhiston":     False,
    "attribution": {
        "greek": (
            "BeDuhn–Bilby Greek reconstruction of Marcion's Evangelion. "
            "Mark G. Bilby and Jason D. BeDuhn, "
            "Journal of Open Humanities Data (2023). CC BY-NC-ND. "
            "https://openhumanitiesdata.metajnl.com/articles/10.5334/johd.126"
        ),
        "translation": (
            "Translated by Mistral 7B (mistral:7b via Ollama). "
            "Machine translation, unreviewed."
        ),
        "lacunae": (
            "() in source = lacuna (missing text), rendered as … "
            "[] in source = reconstructed/uncertain text, shown as-is."
        )
    },
    "verses": verses
}

os.makedirs("docs/data", exist_ok=True)
with open(OUT_JSON, "w", encoding="utf-8") as f:
    json.dump(book, f, ensure_ascii=False, indent=2)
print(f"Written:  {OUT_JSON}")

# ── Update index.json ──
if os.path.exists(INDEX_JSON):
    with open(INDEX_JSON, encoding="utf-8") as f:
        books = json.load(f)
    if isinstance(books, dict):
        books = books.get("books", [])
else:
    books = []

books = [b for b in books if b.get("code") != "marcion"]
books.append({
    "code":           "marcion",
    "name":           "Evangelion",
    "author":         "Marcion (BeDuhn–Bilby recon.)",
    "type":           "prose",
    "group":          "apocrypha",
    "verseCount":     len(verses),
    "hasTranslation": has_translation,
    "hasKjv":         False,
    "hasWhiston":     False
})

with open(INDEX_JSON, "w", encoding="utf-8") as f:
    json.dump(books, f, ensure_ascii=False, indent=2)
print(f"Updated:  {INDEX_JSON}")
print(f"\nDone — {len(verses)} verses ready.")
print(f"To translate: python3 translate_marcion.py")
